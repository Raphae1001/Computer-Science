#!/usr/bin/env python3
import sys
import os

# =======================
#   TABLES HACK
# =======================

COMP_TABLE = {
    "0":   "0101010",
    "1":   "0111111",
    "-1":  "0111010",
    "D":   "0001100",
    "A":   "0110000",
    "M":   "1110000",
    "!D":  "0001101",
    "!A":  "0110001",
    "!M":  "1110001",
    "-D":  "0001111",
    "-A":  "0110011",
    "-M":  "1110011",
    "D+1": "0011111",
    "A+1": "0110111",
    "M+1": "1110111",
    "D-1": "0001110",
    "A-1": "0110010",
    "M-1": "1110010",
    "D+A": "0000010",
    "D+M": "1000010",
    "D-A": "0010011",
    "D-M": "1010011",
    "A-D": "0000111",
    "M-D": "1000111",
    "D&A": "0000000",
    "D&M": "1000000",
    "D|A": "0010101",
    "D|M": "1010101",
}

DEST_TABLE = {
    "":    "000",
    "M":   "001",
    "D":   "010",
    "MD":  "011",
    "A":   "100",
    "AM":  "101",
    "AD":  "110",
    "AMD": "111",
}

JUMP_TABLE = {
    "":    "000",
    "JGT": "001",
    "JEQ": "010",
    "JGE": "011",
    "JLT": "100",
    "JNE": "101",
    "JLE": "110",
    "JMP": "111",
}

# =======================
#   FONCTIONS UTIL
# =======================

def clean_line(line: str) -> str:
    """Remove comments and whitespace, return '' if line is empty."""
    comment_index = line.find("//")
    if comment_index != -1:
        line = line[:comment_index]
    return line.strip()


def is_label(line: str) -> bool:
    return line.startswith("(") and line.endswith(")")


def get_label_name(line: str) -> str:
    # line is like "(LOOP)"
    return line[1:-1].strip()


def is_A_instruction(line: str) -> bool:
    return line.startswith("@")

# =======================
#   ASSEMBLER 2 PASSES
# =======================

def first_pass(lines):
    """
    First pass: build symbol table with labels.
    Returns symbol_table and list of (non-empty) lines (labels included).
    """
    symbol_table = {
        "SP":     0,
        "LCL":    1,
        "ARG":    2,
        "THIS":   3,
        "THAT":   4,
        "SCREEN": 16384,
        "KBD":    24576,
    }
    for i in range(16):
        symbol_table[f"R{i}"] = i

    cleaned_lines = []
    rom_address = 0  # address of the next instruction (A or C)

    for raw in lines:
        line = clean_line(raw)
        if not line:
            continue
        cleaned_lines.append(line)
        if is_label(line):
            label = get_label_name(line)
            if label not in symbol_table:
                symbol_table[label] = rom_address
        else:
            rom_address += 1

    return symbol_table, cleaned_lines


def canonical_dest(dest: str) -> str:
    """
    Handle the known bug: accept DM or MD as MD, and ADM or AMD as AMD.
    """
    dest = dest.strip()
    if dest in ("DM", "MD"):
        return "MD"
    if dest in ("ADM", "AMD"):
        return "AMD"
    return dest


def parse_C_instruction(line: str):
    """
    Split C-instruction into (dest, comp, jump).
    Forms: dest=comp;jump | comp;jump | dest=comp | comp
    """
    dest = ""
    jump = ""
    rest = line

    if "=" in rest:
        dest, rest = rest.split("=", 1)
        dest = dest.strip()
    if ";" in rest:
        comp, jump = rest.split(";", 1)
        comp = comp.strip()
        jump = jump.strip()
    else:
        comp = rest.strip()

    dest = canonical_dest(dest)
    return dest, comp, jump


def assemble_A(line: str, symbol_table, next_free_addr_ref):
    """
    Translate an A-instruction (e.g. @21, @LOOP, @i) to binary.
    next_free_addr_ref is a dict with key "value" holding next free RAM address (for variables).
    """
    symbol = line[1:].strip()
    if symbol.isdigit():
        value = int(symbol)
    else:
        if symbol not in symbol_table:
            symbol_table[symbol] = next_free_addr_ref["value"]
            next_free_addr_ref["value"] += 1
        value = symbol_table[symbol]

    if value < 0 or value > 32767:
        raise ValueError(f"Value out of range for A-instruction: {value}")
    return "0" + format(value, "015b")


def assemble_C(line: str):
    dest, comp, jump = parse_C_instruction(line)

    if comp not in COMP_TABLE:
        raise ValueError(f"Unknown comp: {comp!r} in line: {line!r}")
    if canonical_dest(dest) not in DEST_TABLE:
        raise ValueError(f"Unknown dest: {dest!r} in line: {line!r}")
    if jump not in JUMP_TABLE:
        raise ValueError(f"Unknown jump: {jump!r} in line: {line!r}")

    comp_bits = COMP_TABLE[comp]
    dest_bits = DEST_TABLE[canonical_dest(dest)]
    jump_bits = JUMP_TABLE[jump]

    return "111" + comp_bits + dest_bits + jump_bits


def second_pass(cleaned_lines, symbol_table):
    """
    Second pass: generate binary lines, handling variables.
    """
    hack_lines = []
    next_free_addr_ref = {"value": 16}

    for line in cleaned_lines:
        if is_label(line):
            continue  # labels are not translated
        if is_A_instruction(line):
            hack_line = assemble_A(line, symbol_table, next_free_addr_ref)
        else:
            hack_line = assemble_C(line)
        hack_lines.append(hack_line)

    return hack_lines

# =======================
#   MAIN
# =======================

def assemble_file(input_path: str):
    if not os.path.isfile(input_path):
        print(f"Error: '{input_path}' is not a file")
        sys.exit(1)

    with open(input_path, "r", encoding="utf-8") as f:
        lines = f.readlines()

    symbol_table, cleaned_lines = first_pass(lines)
    hack_lines = second_pass(cleaned_lines, symbol_table)

    base, _ = os.path.splitext(input_path)
    output_path = base + ".hack"

    # IMPORTANT : pas de ligne vide à la fin
    with open(output_path, "w", encoding="utf-8", newline="\n") as f:
        f.write("\n".join(hack_lines))


def main():
    if len(sys.argv) != 2:
        print("Usage: Assembler <path/to/Prog.asm>")
        sys.exit(1)
    input_path = sys.argv[1]
    assemble_file(input_path)


if __name__ == "__main__":
    main()